package sample;

public enum Operands {
    ADD,SUBTRACT,MULTIPLY,DIVIDE;
}
